# Payroll
Assignment 10

Following the Domain Driven Design (payroll) class demonstration. Write your payroll (maven) application using IntelliJ showing 
the domains for the Employee, Gender and Race. Your implementation should also include factories, repositories and service 
for the domains. Implement a service to save an Employee given firstname, lastname , gender and race.

Use TDD.
